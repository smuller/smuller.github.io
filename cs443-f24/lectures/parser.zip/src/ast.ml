type bop = Plus | Times | Minus
type exp = Num of int
         | Binop of bop * exp * exp
