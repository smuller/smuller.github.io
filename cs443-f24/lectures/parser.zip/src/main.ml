(*
let rec repl () =
  let lexbuf = Lexing.from_channel stdin in
  let n = Parser.prog Lexer.token lexbuf in
  Printf.printf "%d\n%!" n;
  repl ()
 *)

open Ast

let rec interp_exp e =
  match e with
  | Num n -> n
  | Binop (b, e1, e2) ->
     let n1 = interp_exp e1 in
     let n2 = interp_exp e2 in
     let f = match b with Plus -> (+) | Minus -> (-) | Times -> ( * ) in
     f n1 n2

let rec repl () =
  let lexbuf = Lexing.from_channel stdin in
  let e = Parser.prog Lexer.token lexbuf in
  let n = interp_exp e in
  Printf.printf "%d\n%!" n;
  repl ()

  
let () = repl ()

